package com.example.practica9;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document(collection = "AccesoADatosCollection")
public class Pokemon {

    @Id
    private String id;

    private String name;
    private String type;
    private int level;
    private String trainer;
    private Date date;

    public Pokemon() {}

    public Pokemon(String id, String name, String type, int level, String trainer, Date date) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.level = level;
        this.trainer = trainer;
        this.date = date;
    }

    public String getId() { return id; }

    public String getName() { return name; }

    public String getType() { return type; }

    public int getLevel() { return level; }

    public String getTrainer() { return trainer; }

    public Date getDate() { return date; }

    public void setId(String id) { this.id = id; }

    public void setName(String name) { this.name = name; }

    public void setType(String type) { this.type = type; }

    public void setLevel(int level) { this.level = level; }

    public void setTrainer(String trainer) { this.trainer = trainer; }

    public void setDate(Date date) { this.date = date; }

    
    
    @Override
    public String toString() {
        return "Pokemon{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                ", type =" + type + '\'' +
                ", level =" + level + '\'' +
                ", trainer =" + trainer + '\'' +
                ", date=" + date +
                '}';
    }

}