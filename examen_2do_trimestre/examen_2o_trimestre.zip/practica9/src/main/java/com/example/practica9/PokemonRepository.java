package com.example.practica9;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface PokemonRepository extends MongoRepository<Pokemon, String> {

    //Obtener pokemones capturados por el team NDT
    List<Pokemon> findAll();
    
    // Obtener pokemones de nivel mayor a una dada
    List<Pokemon> findByLevelGreaterThan(double quantity);
    
    // Obtener pokemones con nivel entre dos valores
    List<Pokemon> findByLevelBetween(double min, double max);
    
    
    //Obtener pokemones capturados por un entrenador (no utilizado)
    List<Pokemon> findByTrainerContainingIgnoreCase(String text);
    
    // Obtener todos los pokemones antes de una fecha
    List<Pokemon> findByDateBefore(Date date);
    
    //Obtener pokemones cuyo nombre contenga una palabra determinada
    List<Pokemon> findByNameContainingIgnoreCase(String text);
    
    //Obtener pokemones de un tipo determinado
    List<Pokemon> findByTypeContainingIgnoreCase(String text);
    
}
