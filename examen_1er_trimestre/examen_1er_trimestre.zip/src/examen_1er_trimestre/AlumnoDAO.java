package examen_1er_trimestre;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class AlumnoDAO {
    
    private Connection connection;
    
    public AlumnoDAO(Connection connection) {
        this.connection = connection;
    }
    
    // 1. Listar todos los datos de todos los usuarios
    public ArrayList<Alumno> findAll() {
        String sql = "SELECT * FROM ALUMNOS ORDER BY id";
        ArrayList<Alumno> alumnos = new ArrayList<>();
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();
            while (resultSet.next()) {
                Alumno alumno = new Alumno(
                    resultSet.getInt("id"),
                    resultSet.getString("nombre"),
                    resultSet.getInt("curso")
                );
                alumnos.add(alumno);
            }
        } catch (SQLException sqle) {
            System.out.println("Error al listar todos los usuarios");
            sqle.printStackTrace();
        }

        return alumnos;
    }
    
    
    // 2. Añadir un nuevo usuario
    public void insertarAlumno(Alumno alumno) {
        String sql = "INSERT INTO ALUMNOS (nombre, curso) VALUES (?, ?)";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, alumno.getNombre());
            statement.setInt(2, alumno.getCurso());
            statement.executeUpdate();
        } catch (SQLException sqle) {
            System.out.println("Error al añadir un nuevo usuario");
            sqle.printStackTrace();
        }
    }
    
    // 3. Eliminar un usuario proporcionando su ID
    public void eliminarAlumno(int id) {
        String sql = "DELETE FROM ALUMNOS WHERE id = ?";
        try {
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, id);
            statement.executeUpdate();
    
        } catch (SQLException sqle) {
            System.out.println("Error al eliminar usuario");
            sqle.printStackTrace();
        }
    }
    
    // 4. Listar alumnos de un curso especifico
    public ArrayList<Alumno> findByCurso(int curso) {
        String sql = "SELECT * FROM ALUMNOS WHERE curso = ?";
        // Creo una lista vacía donde se almacenarán los jugadores encontrados
        ArrayList<Alumno> alumnos = new ArrayList<>();
        try {
            // Preparo la sentencia SQL para poder asignar valores dinámicamente
            PreparedStatement statement = connection.prepareStatement(sql);
    
            // Asigno el valor del entrenadorId recibido como argumento al parámetro (?)
            statement.setInt(1, curso);
    
            // Ejecuto la consulta SELECT y obtengo el resultado en un ResultSet
            ResultSet resultSet = statement.executeQuery();
    
            // Recorro todas las filas devueltas por la consulta
            while (resultSet.next()) {
                Alumno alumno = new Alumno(
                    resultSet.getInt("id"),
                    resultSet.getString("nombre"),
                    resultSet.getInt("curso")
                );
                // Añade el jugador creado a la lista
                alumnos.add(alumno);
            }
        } catch (SQLException sqle) {
            System.out.println("Error al listar los alumnos del curso");
            sqle.printStackTrace();
        }
        return alumnos;
    }
    
}
