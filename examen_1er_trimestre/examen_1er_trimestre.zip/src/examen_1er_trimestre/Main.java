/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package examen_1er_trimestre;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Connection conn = null;
        Scanner sc = new Scanner(System.in);

        try {
            conn = DriverManager.getConnection(
                ConfiguracionXML.getUrl(),
                ConfiguracionXML.getUsuario(),
                ConfiguracionXML.getPassword()
            );
            
            AlumnoDAO alumnoDAO = new AlumnoDAO(conn);
            
            int opcion;
            do {
                mostrarMenu();
                opcion = sc.nextInt();
                sc.nextLine();

                switch (opcion) {
                    case 1: 
                        ArrayList<Alumno> alumnos = alumnoDAO.findAll();
                        System.out.println("------ LISTA DE ALUMNOS ------");
                        for (int i = 0; i < alumnos.size(); i++) {
                            Alumno alu = alumnos.get(i);
                            System.out.println(alu.getId() + " - " + alu.getNombre() +
                                " Curso: " + alu.getCurso());
                        }
                        break;
                        
                    case 2:
                        System.out.print("Nombre: ");
                        String nombreAlumno = sc.nextLine();
                        System.out.println("Recuarda que el alumno solo puede estar cursando 1 o 2 ");
                        System.out.print("Curso: ");
                        int curso = sc.nextInt();
                        if (curso != 1 && curso != 2) {
                            System.out.println("El curso no existe. Alumno no guardado, intentelo de nuevo");
                            break;
                        }
                        sc.nextLine();
                        Alumno a = new Alumno(0, nombreAlumno, curso);
                        alumnoDAO.insertarAlumno(a);
                        System.out.println("------ ALUMNO ANIADIDO CORRECTAMENTE ------");
                        break;
                    case 3:
                        System.out.print("Id del alumno que quieras eliminar: ");
                        int idDelA = sc.nextInt();
                        alumnoDAO.eliminarAlumno(idDelA);
                        System.out.println("------ ALUMNO ELIMINADO CORRECTAMENTE ------");
                        break;
                    case 4:
                        System.out.println("Recuarda que los alumnos solo pueden estar cursando 1 o 2 ");
                        System.out.print("Numero de curso: ");
                        int numCurso = sc.nextInt();
                        if (numCurso != 1 && numCurso != 2) {
                            System.out.println("El curso no existe. Intentelo de nuevo");
                            break;
                        }
                        sc.nextLine();
                        System.out.println("------ LISTA DE ALUMNOS DE " + numCurso + " ------");
                        ArrayList<Alumno> alumnosCurso = alumnoDAO.findByCurso(numCurso);
                        for (int i = 0; i < alumnosCurso.size(); i++) {
                            Alumno alum = alumnosCurso.get(i);
                            System.out.println(alum.getId() + " - " + alum.getNombre());
                        }
                        break;
                    case 0:
                        System.out.println("Saliendo...");
                        break;
                    default:
                        System.out.println("Opcion no valida");
                }

            } while (opcion != 0);
            
        } catch (SQLException sqle) {
            System.out.println("Error de conexion con la base de datos");
            sqle.printStackTrace();
        } finally {
            try {
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
            sc.close();
        }
    }
    
    
    public static void mostrarMenu() {
        System.out.println("===============================================================");
        System.out.println("                       QUE QUIERES HACER?                      ");
        System.out.println("===============================================================");
        System.out.println("1. Listar todos los datos de todos los usuarios");
        System.out.println("2. Aniadir un nuevo usuario");
        System.out.println("3. Eliminar un usuario proporcionando su ID");
        System.out.println("4. Listar unicamente el nombre de los usuarios de un curso especifico");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opcion: ");
    }
    
    
}
