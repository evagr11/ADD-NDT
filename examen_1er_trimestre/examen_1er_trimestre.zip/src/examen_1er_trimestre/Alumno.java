package examen_1er_trimestre;

public class Alumno {
    
    private int id;
    private String nombre;
    private int curso;

    public Alumno(int id, String nombre, int curso) {
        this.id = id;
        this.nombre = nombre;
        this.curso = curso;
    }

    public int getId() { return id; }

    public String getNombre() { return nombre; }

    public int getCurso() { return curso; }

    public void setId(int id) { this.id = id; }

    public void setNombre(String nombre) { this.nombre = nombre; }

    public void setCurso(int curso) { this.curso = curso; }

}
