package examen_1er_trimestre;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class ConfiguracionXML {
    
    private static String url;
    private static String usuario;
    private static String password;
    
    static {
        try {
            // Crea un objeto File que apunta al fichero config.xml
            File file = new File("config.xml");

            // Obtiene una instancia de la fábrica de constructores de documentos XML
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            // Crea el parser DOM (DocumentBuilder) a partir de la fábrica
            DocumentBuilder builder = factory.newDocumentBuilder();
            // Parsea el fichero XML y lo carga en memoria como un objeto Document
            Document doc = builder.parse(file);
            // Normaliza la estructura del documento (elimina nodos vacíos, etc.)
            doc.getDocumentElement().normalize();

            // Configura la fábrica para ignorar espacios en blanco entre elementos
            factory.setIgnoringElementContentWhitespace(true);

            // Crea un objeto XPath para realizar consultas sobre el XML
            XPath xPath = XPathFactory.newInstance().newXPath();
            // Define la expresión XPath para seleccionar el nodo raíz <config>
            String expression = "/config";
            // Compila y evalúa la expresión XPath sobre el documento, obteniendo los nodos <config>
            NodeList nodeList = (NodeList) xPath.compile(expression).evaluate(doc, XPathConstants.NODESET);

            // Recorre todos los nodos encontrados (en este caso, los <config>)
            for (int i = 0; i < nodeList.getLength(); i++){
                // Obtiene el nodo actual
                Node nNode = nodeList.item(i);
                // Imprime el nombre del nodo actual (debería ser "config")
                System.out.println("Current Element: " + nNode.getNodeName());
                // Convierte el nodo a tipo Element para acceder a sus hijos
                Element eElement = (Element) nNode;
                // Extrae el texto del primer elemento <url> y lo asigna a la variable url
                url = eElement.getElementsByTagName("url").item(0).getTextContent();
                usuario = eElement.getElementsByTagName("user").item(0).getTextContent();
                password = eElement.getElementsByTagName("password").item(0).getTextContent();
            }
            
        } catch (Exception e) {
            System.err.println("Error al leer el fichero config.xml");
            e.printStackTrace();
        }
    }

    public static String getUrl() {
        return url;
    }

    public static String getUsuario() {
        return usuario;
    }

    public static String getPassword() {
        return password;
    }

}
